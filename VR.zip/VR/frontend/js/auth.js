// API URL
const API_URL = 'http://localhost:5000/api/v1';

// Show loading spinner
function showLoading(form) {
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    button.innerHTML = '<div class="loading-spinner"></div> Please wait...';
}

// Hide loading spinner
function hideLoading(form, originalText) {
    const button = form.querySelector('button[type="submit"]');
    button.disabled = false;
    button.innerHTML = originalText;
}

// Handle Start Journey
function handleStartJourney() {
    const token = localStorage.getItem('token');
    if (token) {
        // If user is logged in, redirect to tours section
        window.location.href = '#tours';
    } else {
        // If user is not logged in, redirect to login page
        window.location.href = 'login.html';
    }
}

// Handle Login
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        showLoading(loginForm);
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch(`${API_URL}/users/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password }),
                credentials: 'include'
            });

            const data = await response.json();

            if (data.success) {
                // Store token in localStorage
                localStorage.setItem('token', data.token);
                localStorage.setItem('userName', data.user.name);
                // Redirect to home page
                window.location.href = 'index.html#tours';
            } else {
                throw new Error(data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Invalid email or password. Please try again.');
            hideLoading(loginForm, 'Login');
        }
    });
}

// Handle Registration
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        showLoading(registerForm);
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match');
            hideLoading(registerForm, 'Sign Up');
            return;
        }

        try {
            const response = await fetch(`${API_URL}/users/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ name, email, password }),
                credentials: 'include'
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Store token in localStorage
                localStorage.setItem('token', data.token);
                localStorage.setItem('userName', data.user.name);
                // Redirect to success page
                window.location.href = 'success.html';
            } else {
                throw new Error(data.message || 'Registration failed. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            if (error.message === 'Failed to fetch') {
                alert('Unable to connect to the server. Please check if the server is running.');
            } else {
                alert(error.message || 'Registration failed. Please try again.');
            }
            hideLoading(registerForm, 'Sign Up');
        }
    });
}

// Check Authentication Status
function checkAuth() {
    const token = localStorage.getItem('token');
    const userName = localStorage.getItem('userName');

    // Update navigation based on auth status
    const nav = document.querySelector('nav');
    if (nav) {
        if (token) {
            // Add user name and logout button if logged in
            const authLinks = Array.from(nav.querySelectorAll('a')).filter(link => 
                link.href.includes('login.html') || link.href.includes('register.html')
            );
            
            authLinks.forEach(link => link.remove());
            
            const userNameSpan = document.createElement('span');
            userNameSpan.textContent = `Welcome, ${userName || 'User'}`;
            userNameSpan.style.color = '#ffcc00';
            
            const logoutLink = document.createElement('a');
            logoutLink.href = '#';
            logoutLink.textContent = 'Logout';
            logoutLink.onclick = (e) => {
                e.preventDefault();
                logout();
            };
            
            nav.appendChild(userNameSpan);
            nav.appendChild(logoutLink);
        }
    }

    // Add click handler for Start Journey button
    const startJourneyBtn = document.querySelector('.cta');
    if (startJourneyBtn) {
        startJourneyBtn.addEventListener('click', handleStartJourney);
    }
}

// Logout Function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userName');
    window.location.href = 'index.html';
}

// Check auth status when page loads
document.addEventListener('DOMContentLoaded', checkAuth); 